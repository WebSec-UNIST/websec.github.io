import math
import utils

class ALU:
    # do not modify this function
    def __init__(self):
        pass

    #FIXME
    def operate(self, operation, operand1, operand2):
        """
        Perform ALU operation based on the operation code.

        Parameters:
            - operation (int): The 4-bit ALU control signal that determines
              the operation to be performed.
            - operand1 (int): The first operand (32-bit data) for the ALU
              operation.
            - operand2 (int): The second operand (32-bit data) for the ALU
              operation.

        Functionality:
            - This function performs ALU operations based on the operation
              argument and the operand1 and operand2 arguments. It returns the
              result of the operation along with a zero flag.


        Returns:
            - A tuple (result, zero), where:
                - result (int): Result of the ALU operation.
                - zero (int): A flag indicating if the result is zero (1 if
                              zero, otherwise 0).

        /*************************************************/
        /********************* FIXME *********************/
        /*************************************************/
        """
